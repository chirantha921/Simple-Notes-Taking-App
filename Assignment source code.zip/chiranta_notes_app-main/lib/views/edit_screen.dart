import 'package:flutter/material.dart';
import 'package:my_simple_note/services/databases.dart';
import 'package:my_simple_note/views/home_screen.dart';

class EditNote extends StatefulWidget {
  final int id;
  final String title;
  final String content;

  const EditNote({
    super.key,
    required this.id,
    required this.title,
    required this.content,
  });

  @override
  State<EditNote> createState() => _EditNoteState();
}

class _EditNoteState extends State<EditNote> {
  final TextEditingController titleController = TextEditingController();
  final TextEditingController contentController = TextEditingController();

  @override
  void initState() {
    super.initState();
    titleController.text = widget.title;
    contentController.text = widget.content;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'Edit Notes',
          style: TextStyle(
            color: Colors.black,
            fontSize: 20.0,
            fontWeight: FontWeight.w500,
          ),
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 20),
        child: Column(
          children: [
            const SizedBox(height: 20),
            TextFormField(
              controller: titleController,
              decoration: const InputDecoration(
                hintText: 'Title',
                labelText: 'Title',

                //border
                border: OutlineInputBorder(
                  borderSide: BorderSide(color: Colors.black),
                ),
              ),
            ),
            const SizedBox(height: 20),
            TextFormField(
              controller: contentController,
              maxLines: 10,
              decoration: const InputDecoration(
                hintText: 'Content',
                labelText: 'Content',
                border: OutlineInputBorder(
                  borderSide: BorderSide(color: Colors.black),
                ),
              ),
            ),
            const SizedBox(height: 20),
            ElevatedButton(
              onPressed: () {
                print('Title: ${titleController.text}');

                print('Content: ${contentController.text}');

                if (titleController.text.isEmpty ||
                    contentController.text.isEmpty) {
                  return;
                }

                SqfLite.editNote(
                  id: widget.id,
                  title: titleController.text,
                  content: contentController.text,
                );

                titleController.clear();
                contentController.clear();

                Navigator.pop(context);
              },
              child: const Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(Icons.edit),
                  Text('Edit'),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
