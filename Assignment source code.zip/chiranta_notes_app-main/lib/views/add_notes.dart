import 'package:flutter/material.dart';
import 'package:my_simple_note/services/databases.dart';

import 'home_screen.dart';

class AddNotes extends StatelessWidget {
  const AddNotes({super.key});

  @override
  Widget build(BuildContext context) {
    TextEditingController titleController = TextEditingController();
    TextEditingController contentController = TextEditingController();

    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'Add Notes',
          style: TextStyle(
            color: Colors.black,
            fontSize: 20.0,
            fontWeight: FontWeight.w500,
          ),
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 20),
        child: Column(
          children: [
            const SizedBox(height: 20),
            TextFormField(
              controller: titleController,
              decoration: const InputDecoration(
                hintText: 'Title',
                labelText: 'Title',

                //border
                border: OutlineInputBorder(
                  borderSide: BorderSide(color: Colors.black),
                ),
              ),
            ),
            const SizedBox(height: 20),
            TextFormField(
              controller: contentController,
              maxLines: 10,
              decoration: const InputDecoration(
                hintText: 'Content',
                labelText: 'Content',
                border: OutlineInputBorder(
                  borderSide: BorderSide(color: Colors.black),
                ),
              ),
            ),
            const SizedBox(height: 20),
            ElevatedButton(
              onPressed: () {
                print('Title: ${titleController.text}');

                print('Content: ${contentController.text}');

                if (titleController.text.isEmpty ||
                    contentController.text.isEmpty) {
                  return;
                }

                SqfLite.addNote(
                  title: titleController.text,
                  content: contentController.text,
                  date: DateTime.now().toString(),
                );

                titleController.clear();
                contentController.clear();


                // Navigator.pushReplacement(
                //   context,
                //   MaterialPageRoute(
                //     builder: (context) => const HomeScreen(),
                //   ),
                // );

                Navigator.pop(context);
              },
              child: const Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(Icons.save),
                  Text('Save'),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
