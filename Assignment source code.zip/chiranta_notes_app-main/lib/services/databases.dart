import 'package:sqflite/sqflite.dart';

class SqfLite {
  static Database? database;

  // Initialize database

  static Future<void> initDatabase() async {
    if (database != null) {
      print('Database already created');
      return;
    }
    database = await openDatabase(
      'notes_database.db',
      version: 1,
      onCreate: (db, version) async {
        await db.execute('''
      CREATE TABLE notes(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        title TEXT,
        content TEXT,
        date TEXT
      )''');
        print('Table created successfully');
      },
    );

    print('Database created successfully');
  }
// Function to create tables in the database

  /// Table Name: notes
  /// int id : notes id (unique)
  /// String title : title of the note (String)
  /// String content : content of the note (String)
  /// String date : date of the note (String)
//

  static Future<void> createNotesTable() async {
    if (database == null) {
      await initDatabase();
    }

    /// if table is already created dont create it again
    await database!.execute('''
    CREATE TABLE notes(
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      title TEXT,
      content TEXT,
      date TEXT
    )''');

    print('Table created successfully');
  }

  ///Fucntion to add and note in the database and table notes

  static Future<void> addNote({
    required String title,
    required String content,
    required String date,
  }) async {
    if (database == null) {
      await initDatabase();
    }

    print('Adding note');
    print('Title: $title, Content: $content, Date: $date');
    await database!.insert('notes', {
      'title': title,
      'content': content,
      'date': date,
    });

    print('Note added successfully');
  }

  ///Function to get all notes from the database

  static Future<List<Map<String, dynamic>>> getNotes() async {
    if (database == null) {
      await initDatabase();
    }

    final notes = await database!.query('notes');

    print(notes);
    return notes;
  }

  /// Function to delete a note from the database
  static Future<void> deleteNote({required int id}) async {
    if (database == null) {
      await initDatabase();
    }

    await database!.delete('notes', where: 'id = ?', whereArgs: [id]);

    print('Note deleted successfully');

  }


  static Future<void> editNote({
    required int id,
    required String title,
    required String content,
  }) async {

    if (database == null) {
      await initDatabase();
    }

    await database!.update(
      'notes',
      {
        'title': title,
        'content': content,
      },
      where: 'id = ?',
      whereArgs: [id],
    );

    print('Note updated successfully');
  }
}
