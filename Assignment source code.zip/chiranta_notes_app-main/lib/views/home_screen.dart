import 'package:flutter/material.dart';
import 'package:my_simple_note/services/databases.dart';
import 'package:my_simple_note/utils/app_colors.dart';
import 'package:my_simple_note/views/add_notes.dart';
import 'package:my_simple_note/views/components/note_tile.dart';
import 'package:my_simple_note/views/edit_screen.dart';
import 'package:my_simple_note/views/view_notes.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  @override
  void initState() {
    SqfLite.initDatabase();
    // SqfLite.createNotesTable();

    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      floatingActionButtonLocation: FloatingActionButtonLocation.centerFloat,
      floatingActionButton: FloatingActionButton(
        backgroundColor: CustomColors.kSecondaryColor,
        onPressed: () async {
          Navigator.push(context,
                  MaterialPageRoute(builder: (context) => const AddNotes()))
              .whenComplete(() {
            setState(() {});
          });
        },
        child: const Icon(Icons.add, color: Colors.white),
      ),
      appBar: AppBar(
        title: const Text(
          "Recent Notes",
          style: TextStyle(
            color: Colors.black,
            fontSize: 20.0,
            fontWeight: FontWeight.w500,
          ),
        ),
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            const Divider(
              height: 1.0,
              color: Colors.grey,
            ),
            FutureBuilder(
              future: SqfLite.getNotes(),
              builder: (context, snapshot) {
                if (snapshot.connectionState == ConnectionState.waiting) {
                  return const Center(child: CircularProgressIndicator());
                }
                if (snapshot.hasError) {
                  return  Center(child: Text('Something went wrong ${snapshot.error}' ));
                }

                List<Map<String, dynamic>> notes =
                    snapshot.data as List<Map<String, dynamic>>;

                if (notes.isEmpty) {
                  return const Center(
                    child: Padding(
                      padding:
                          EdgeInsets.symmetric(horizontal: 50, vertical: 100),
                      child: Text('No notes added yet'),
                    ),
                  );
                }

                return ListView.builder(
                  physics: const NeverScrollableScrollPhysics(),
                  itemCount: notes.length,
                  shrinkWrap: true,
                  itemBuilder: (context, index) {
                    return NoteTile(
                      noteTitle: notes[index]['title'],
                      noteContent: notes[index]['content'],
                      onDelete: () {
                        setState(() {
                          SqfLite.deleteNote(id: notes[index]['id']);
                        });
                      },
                      onEdit: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) => EditNote(
                              id: notes[index]['id'],
                              title: notes[index]['title'],
                              content: notes[index]['content'],
                            ),
                          ),
                        ).whenComplete(() {
                          setState(() {});
                        });
                      },
                      onTap: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) => ViewNotes(
                              noteTitle: notes[index]['title'],
                              noteContent: notes[index]['content'],
                              id: notes[index]['id'],
                            ),
                          ),
                        );
                      },
                    );
                  },
                );
              },
            ),
          ],
        ),
      ),
    );
  }
}
