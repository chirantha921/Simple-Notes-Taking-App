import 'dart:ui';

class CustomColors {
  static const Color kNotesColor = Color(0xFFFDF3BF);
  static const Color kSecondaryColor = Color(0xFFE8505B);
}
