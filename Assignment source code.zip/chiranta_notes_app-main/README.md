# my_simple_note

Simple Notes raking app for learning

## Getting Started


## Architecture

 - Frontend: Flutter
 - Logic: Dart Language
 - Storage: SQLite
 - State Management: None
 - Version Control: Git/Github
 - CI/CD: None

## Features
     - Add Note
     - Edit Note
     - Delete Note
     - List Notes
     - About



