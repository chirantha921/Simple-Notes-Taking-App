import 'package:flutter/material.dart';
import 'package:my_simple_note/utils/app_colors.dart';

class NoteTile extends StatelessWidget {
  final String noteTitle;
  final String noteContent;
  final Function onDelete;
  final Function onEdit;
  final Function onTap;

  const NoteTile(
      {super.key,
      required this.noteTitle,
      required this.noteContent,
      required this.onDelete,
      required this.onEdit,
      required this.onTap});

  @override
  Widget build(BuildContext context) {
    return InkWell(
        onTap: () {
          onTap();
        },
        child: Container(
          height: 120.0,
          margin: const EdgeInsets.symmetric(horizontal: 10.0, vertical: 7.0),
          decoration: BoxDecoration(
            color: CustomColors.kNotesColor,
            borderRadius: BorderRadius.circular(10.0),
          ),
          padding: const EdgeInsets.all(10.0),
          child: Row(
            children: [
              Expanded(
                flex: 8,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      noteTitle,
                      maxLines: 1,
                      style: const TextStyle(
                        color: Colors.black,
                        fontSize: 16.0,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                    const SizedBox(height: 2.0),
                    Text(
                      noteContent,
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(
                        color: Colors.black,
                        fontSize: 14.0,
                        fontWeight: FontWeight.w400,
                      ),
                    ),
                  ],
                ),
              ),
              Expanded(
                flex: 1,
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    InkWell(
                      onTap: () {
                        onEdit();
                      },
                      child: const Icon(
                        Icons.edit,
                        color: Colors.black87,
                      ),
                    ),
                    InkWell(
                      onTap: () {
                        onDelete();
                      },
                      child: const Icon(
                        Icons.delete_forever,
                        color: CustomColors.kSecondaryColor,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ));
  }
}
