package com.test.my_simple_note

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
